module.exports = {
  content: ['index.html'],
  theme: {
    
    extend: {
      animation:{
      'goyang' : 'goyang 1s ease-in-out infinite',
      'spin'   : 'spin 4s linear infinite',
      },
      keyframes:{
        goyang :{
          '0%, 100%': { transform: 'rotate(-3deg)'}, 
          '50%' : {transform:'rotate(3deg)'},
        }
      }
    },
    screens: {
      'lg': '1024px',
      // => @media (min-width: 1024px) { ... }
      'sm': '640px',
      // => @media (min-width: 640px) { ... }
    },
    container: {
      center: true,
      padding: "1rem",
      screens: {
        lg: "1124px",
        xl: "1124px",
        "2xl": "1124px",
      },
  },
  plugins: [],
}
}
